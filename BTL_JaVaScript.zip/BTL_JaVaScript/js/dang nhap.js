document.getElementById('show-password-checkbox').addEventListener('change', function() {
    var passwordInput = document.getElementById('Mật khẩu');
    if (this.checked) {
        passwordInput.type = 'text';
    } else {
        passwordInput.type = 'password';
    }
    });